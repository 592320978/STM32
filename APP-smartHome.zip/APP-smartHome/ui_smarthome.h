/********************************************************************************
** Form generated from reading UI file 'smarthome.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SMARTHOME_H
#define UI_SMARTHOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SmartHome
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTabWidget *tabWidget;
    QWidget *smartTab;
    QLabel *lightLabel;
    QLabel *tempLabel;
    QLabel *humiLabel;
    QPushButton *livingButton;
    QPushButton *bedroomButton;
    QPushButton *kitchenButton;
    QPushButton *toiletButton;
    QPushButton *alarmButton;
    QWidget *timeTab;
    QLabel *dateLabel;
    QLabel *weekLabel;
    QLabel *timeLabel;
    QWidget *alarmTab;
    QTimeEdit *alarmTimeEdit;
    QWidget *noteTab;
    QTimeEdit *noteTimeEdit;
    QRadioButton *oneRadioButton;
    QRadioButton *twoRadioButton;
    QRadioButton *threeRadioButton;
    QPushButton *commitButton;

    void setupUi(QWidget *SmartHome)
    {
        if (SmartHome->objectName().isEmpty())
            SmartHome->setObjectName(QStringLiteral("SmartHome"));
        SmartHome->resize(600, 800);
        SmartHome->setMinimumSize(QSize(600, 800));
        SmartHome->setMaximumSize(QSize(600, 800));
        verticalLayout = new QVBoxLayout(SmartHome);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(SmartHome);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        label->setFont(font);

        verticalLayout->addWidget(label);

        tabWidget = new QTabWidget(SmartHome);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        smartTab = new QWidget();
        smartTab->setObjectName(QStringLiteral("smartTab"));
        lightLabel = new QLabel(smartTab);
        lightLabel->setObjectName(QStringLiteral("lightLabel"));
        lightLabel->setGeometry(QRect(260, 80, 141, 61));
        tempLabel = new QLabel(smartTab);
        tempLabel->setObjectName(QStringLiteral("tempLabel"));
        tempLabel->setGeometry(QRect(130, 170, 141, 61));
        humiLabel = new QLabel(smartTab);
        humiLabel->setObjectName(QStringLiteral("humiLabel"));
        humiLabel->setGeometry(QRect(380, 170, 141, 61));
        livingButton = new QPushButton(smartTab);
        livingButton->setObjectName(QStringLiteral("livingButton"));
        livingButton->setGeometry(QRect(60, 300, 211, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(14);
        livingButton->setFont(font1);
        bedroomButton = new QPushButton(smartTab);
        bedroomButton->setObjectName(QStringLiteral("bedroomButton"));
        bedroomButton->setGeometry(QRect(310, 300, 221, 61));
        bedroomButton->setFont(font1);
        kitchenButton = new QPushButton(smartTab);
        kitchenButton->setObjectName(QStringLiteral("kitchenButton"));
        kitchenButton->setGeometry(QRect(60, 360, 211, 61));
        kitchenButton->setFont(font1);
        toiletButton = new QPushButton(smartTab);
        toiletButton->setObjectName(QStringLiteral("toiletButton"));
        toiletButton->setGeometry(QRect(310, 360, 221, 61));
        toiletButton->setFont(font1);
        alarmButton = new QPushButton(smartTab);
        alarmButton->setObjectName(QStringLiteral("alarmButton"));
        alarmButton->setGeometry(QRect(90, 500, 401, 41));
        alarmButton->setFont(font1);
        tabWidget->addTab(smartTab, QString());
        timeTab = new QWidget();
        timeTab->setObjectName(QStringLiteral("timeTab"));
        dateLabel = new QLabel(timeTab);
        dateLabel->setObjectName(QStringLiteral("dateLabel"));
        dateLabel->setGeometry(QRect(60, 170, 271, 81));
        weekLabel = new QLabel(timeTab);
        weekLabel->setObjectName(QStringLiteral("weekLabel"));
        weekLabel->setGeometry(QRect(340, 170, 191, 81));
        timeLabel = new QLabel(timeTab);
        timeLabel->setObjectName(QStringLiteral("timeLabel"));
        timeLabel->setGeometry(QRect(50, 310, 491, 141));
        tabWidget->addTab(timeTab, QString());
        alarmTab = new QWidget();
        alarmTab->setObjectName(QStringLiteral("alarmTab"));
        alarmTimeEdit = new QTimeEdit(alarmTab);
        alarmTimeEdit->setObjectName(QStringLiteral("alarmTimeEdit"));
        alarmTimeEdit->setGeometry(QRect(20, 120, 531, 251));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(72);
        alarmTimeEdit->setFont(font2);
        tabWidget->addTab(alarmTab, QString());
        noteTab = new QWidget();
        noteTab->setObjectName(QStringLiteral("noteTab"));
        noteTimeEdit = new QTimeEdit(noteTab);
        noteTimeEdit->setObjectName(QStringLiteral("noteTimeEdit"));
        noteTimeEdit->setGeometry(QRect(20, 60, 541, 211));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(48);
        noteTimeEdit->setFont(font3);
        oneRadioButton = new QRadioButton(noteTab);
        oneRadioButton->setObjectName(QStringLiteral("oneRadioButton"));
        oneRadioButton->setGeometry(QRect(90, 310, 381, 61));
        oneRadioButton->setFont(font1);
        twoRadioButton = new QRadioButton(noteTab);
        twoRadioButton->setObjectName(QStringLiteral("twoRadioButton"));
        twoRadioButton->setGeometry(QRect(90, 380, 381, 61));
        twoRadioButton->setFont(font1);
        threeRadioButton = new QRadioButton(noteTab);
        threeRadioButton->setObjectName(QStringLiteral("threeRadioButton"));
        threeRadioButton->setGeometry(QRect(90, 450, 381, 61));
        threeRadioButton->setFont(font1);
        commitButton = new QPushButton(noteTab);
        commitButton->setObjectName(QStringLiteral("commitButton"));
        commitButton->setGeometry(QRect(310, 560, 211, 61));
        commitButton->setFont(font1);
        tabWidget->addTab(noteTab, QString());

        verticalLayout->addWidget(tabWidget);


        retranslateUi(SmartHome);

        tabWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(SmartHome);
    } // setupUi

    void retranslateUi(QWidget *SmartHome)
    {
        SmartHome->setWindowTitle(QApplication::translate("SmartHome", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt;\">\346\231\272\346\205\247\345\256\266\345\272\255APP</span></p></body></html>", Q_NULLPTR));
        lightLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">0</p></body></html>", Q_NULLPTR));
        tempLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">0</p></body></html>", Q_NULLPTR));
        humiLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">0</p></body></html>", Q_NULLPTR));
        livingButton->setText(QApplication::translate("SmartHome", "\345\256\242\345\216\205\347\201\257", Q_NULLPTR));
        bedroomButton->setText(QApplication::translate("SmartHome", "\345\215\247\345\256\244\347\201\257", Q_NULLPTR));
        kitchenButton->setText(QApplication::translate("SmartHome", "\345\216\250\346\210\277\347\201\257", Q_NULLPTR));
        toiletButton->setText(QApplication::translate("SmartHome", "\345\215\253\347\224\237\351\227\264", Q_NULLPTR));
        alarmButton->setText(QApplication::translate("SmartHome", "\346\212\245\350\255\246", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(smartTab), QApplication::translate("SmartHome", "\346\231\272\346\205\247\345\256\266\345\272\255", Q_NULLPTR));
        dateLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">0000-00-00</p></body></html>", Q_NULLPTR));
        weekLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">\346\230\237\346\234\237</p></body></html>", Q_NULLPTR));
        timeLabel->setText(QApplication::translate("SmartHome", "<html><head/><body><p align=\"center\">00:00:00</p></body></html>", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(timeTab), QApplication::translate("SmartHome", "\345\214\227\344\272\254\346\227\266\351\227\264", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(alarmTab), QApplication::translate("SmartHome", "\351\227\271\351\222\237\350\256\276\347\275\256", Q_NULLPTR));
        oneRadioButton->setText(QApplication::translate("SmartHome", "\346\217\220\351\206\222\346\210\221\345\217\226\345\277\253\351\200\222", Q_NULLPTR));
        twoRadioButton->setText(QApplication::translate("SmartHome", "\346\217\220\351\206\222\346\210\221\345\201\232\351\245\255", Q_NULLPTR));
        threeRadioButton->setText(QApplication::translate("SmartHome", "\346\217\220\351\206\222\346\210\221\345\226\202\347\214\253", Q_NULLPTR));
        commitButton->setText(QApplication::translate("SmartHome", "\347\241\256\345\256\232", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(noteTab), QApplication::translate("SmartHome", "\345\244\207\345\277\230\345\275\225", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SmartHome: public Ui_SmartHome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SMARTHOME_H
