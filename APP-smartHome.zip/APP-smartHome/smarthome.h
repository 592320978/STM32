#ifndef SMARTHOME_H
#define SMARTHOME_H

#include <QWidget>
#include <QtMqtt/qmqttclient.h>
#include <QTimer.h>

namespace Ui {
class SmartHome;
}

#define ON       1
#define OFF      0

#define LIVINGROOM   1
#define BEDROOM      2
#define KITCHEN      3
#define TOILET       4

struct LightState
{
    quint8 livingroom;
    quint8 bedroom;
    quint8 kitchen;
    quint8 toilet;
};

class SmartHome : public QWidget
{
    Q_OBJECT

public:
    explicit SmartHome(QString id, QWidget *parent = 0);
    ~SmartHome();

private:
    void MQTTClientInit();
    void UiInit();
    void DateInit();

private slots:
    void connect_server_success();

    void message_receive(const QByteArray &msg, const QMqttTopicName &topic);

    void on_livingButton_clicked();

    void on_bedroomButton_clicked();

    void on_kitchenButton_clicked();

    void on_toiletButton_clicked();

    void on_alarmButton_clicked();

    void on_tabWidget_tabBarClicked(int index);

    void UpdateTimeSlot();

    void on_alarmTimeEdit_editingFinished();

    void on_commitButton_clicked();

private:
    Ui::SmartHome *ui;
    QString deviceID;
    QMqttClient *client;
    LightState state;
    QTimer *timer;
};

#endif // SMARTHOME_H
