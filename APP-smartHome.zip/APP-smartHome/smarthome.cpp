#include "smarthome.h"
#include "ui_smarthome.h"
#include <QDebug>
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>

SmartHome::SmartHome(QString id, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SmartHome)
{
    ui->setupUi(this);

    deviceID = id;

    MQTTClientInit();

    UiInit();

    DateInit();

    state.bedroom = OFF;
    state.kitchen = OFF;
    state.livingroom = OFF;
    state.toilet = OFF;

}

void SmartHome::DateInit()
{
    ui->dateLabel->setFont(QFont("微软雅黑", 20));
    ui->weekLabel->setFont(QFont("微软雅黑", 20));

    ui->timeLabel->setFont(QFont("微软雅黑", 50));

    timer = new QTimer;
    connect(timer, &QTimer::timeout, this, &SmartHome::UpdateTimeSlot);
    timer->start(1000);
}

void SmartHome::UpdateTimeSlot()
{
    QDateTime curTime = QDateTime::currentDateTime();

    int year = curTime.date().year();
    int mon = curTime.date().month();
    int day = curTime.date().day();
    int week = curTime.date().dayOfWeek();

    int hour = curTime.time().hour();
    int min = curTime.time().minute();
    int sec = curTime.time().second();

    QString dateString = QString::number(year);
    dateString += "-";
    if (mon < 10)
        dateString += "0";
    dateString += QString::number(mon);
    dateString += "-";
    if (day < 10)
        dateString += "0";
    dateString +=QString::number(day);
    ui->dateLabel->setText(dateString);

    QString weekString = "星期";
    switch (week)
    {
        case 1:
            weekString += "一";
            break;
        case 2:
            weekString += "二";
            break;
        case 3:
            weekString += "三";
            break;
        case 4:
            weekString += "四";
            break;
        case 5:
            weekString += "五";
            break;
        case 6:
            weekString += "六";
            break;
        case 7:
            weekString += "日";
            break;
    }
    ui->weekLabel->setText(weekString);

    QString timeString;
    if (hour < 10)
        timeString += "0";
    timeString += QString::number(hour);
    timeString += ":";
    if (min < 10)
        timeString += "0";
    timeString += QString::number(min);
    timeString += ":";
    if (sec < 10)
        timeString += "0";
    timeString += QString::number(sec);

    ui->timeLabel->setText(timeString);
}

void SmartHome::UiInit()
{
    ui->tabWidget->tabBar()->setFont(QFont("微软雅黑", 12));

    ui->lightLabel->setFont(QFont("微软雅黑", 20));
    ui->tempLabel->setFont(QFont("微软雅黑", 16));
    ui->humiLabel->setFont(QFont("微软雅黑", 16));
}

void SmartHome::MQTTClientInit()
{
    client = new QMqttClient;
    client->setHostname("110.42.167.18");
    client->setPort(1884);

    connect(client, &QMqttClient::connected, this, &SmartHome::connect_server_success);

    client->connectToHost();
}

SmartHome::~SmartHome()
{
    delete ui;
}

void SmartHome::connect_server_success()
{
    qDebug() << "connect mqtt server success";

    connect(client, &QMqttClient::disconnected, [this]()
    {
        QMessageBox::warning(this, "连接提示", "MQTT断开连接");
    });

    connect(client, &QMqttClient::messageReceived, this, &SmartHome::message_receive);

    QString topic = deviceID;
    topic += "upload";

    client->subscribe(topic);
}

void SmartHome::message_receive(const QByteArray &msg, const QMqttTopicName &topic)
{
    qDebug() << topic << " " << msg;

    QJsonObject obj = QJsonDocument::fromJson(msg).object();

    int light = obj.value("light").toInt();
    int temp = obj.value("temp").toInt();
    int humi = obj.value("humi").toInt();

    QString tempStr = QString::number(temp);
    tempStr += "℃";

    QString humiStr = QString::number(humi);
    humiStr += "%";

    ui->lightLabel->setText(QString::number(light));
    ui->tempLabel->setText(tempStr);
    ui->humiLabel->setText(humiStr);
}


void SmartHome::on_livingButton_clicked()
{
    QJsonObject obj;

    if (state.livingroom == OFF)
    {
        obj.insert("cmd", "light");
        obj.insert("which", LIVINGROOM);
        obj.insert("state", ON);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->livingButton->setStyleSheet("background-color:silver");

        state.livingroom = ON;
    }
    else
    {
        obj.insert("cmd", "light");
        obj.insert("which", LIVINGROOM);
        obj.insert("state", OFF);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->livingButton->setStyleSheet(ui->alarmButton->styleSheet());

        state.livingroom = OFF;
    }
}

void SmartHome::on_bedroomButton_clicked()
{
    QJsonObject obj;

    if (state.bedroom == OFF)
    {
        obj.insert("cmd", "light");
        obj.insert("which", BEDROOM);
        obj.insert("state", ON);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->bedroomButton->setStyleSheet("background-color:silver");

        state.bedroom = ON;
    }
    else
    {
        obj.insert("cmd", "light");
        obj.insert("which", BEDROOM);
        obj.insert("state", OFF);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->bedroomButton->setStyleSheet(ui->alarmButton->styleSheet());

        state.bedroom = OFF;
    }
}

void SmartHome::on_kitchenButton_clicked()
{
    QJsonObject obj;
    if (state.kitchen == OFF)
    {
        obj.insert("cmd", "light");
        obj.insert("which", KITCHEN);
        obj.insert("state", ON);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->kitchenButton->setStyleSheet("background-color:silver");

        state.kitchen = ON;
    }
    else
    {
        obj.insert("cmd", "light");
        obj.insert("which", KITCHEN);
        obj.insert("state", OFF);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->kitchenButton->setStyleSheet(ui->alarmButton->styleSheet());

        state.kitchen = OFF;
    }
}

void SmartHome::on_toiletButton_clicked()
{
    QJsonObject obj;
    if (state.toilet == OFF)
    {
        obj.insert("cmd", "light");
        obj.insert("which", TOILET);
        obj.insert("state", ON);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->toiletButton->setStyleSheet("background-color:silver");

        state.toilet = ON;
    }
    else
    {
        obj.insert("cmd", "light");
        obj.insert("which", TOILET);
        obj.insert("state", OFF);

        client->publish(deviceID, QJsonDocument(obj).toJson());

        ui->toiletButton->setStyleSheet(ui->alarmButton->styleSheet());

        state.toilet = OFF;
    }
}

void SmartHome::on_alarmButton_clicked()
{
    QJsonObject obj;

    obj.insert("cmd", "buzzer");
    obj.insert("state", ON);

    client->publish(deviceID, QJsonDocument(obj).toJson());
}

void SmartHome::on_tabWidget_tabBarClicked(int index)
{
    if (index == 0)
    {
        QJsonObject obj;

        obj.insert("cmd", "menu");
        obj.insert("tab", "1");

        client->publish(deviceID, QJsonDocument(obj).toJson());
    }
    else if (index == 1)
    {
        QJsonObject obj;

        obj.insert("cmd", "menu");
        obj.insert("tab", "2");

        client->publish(deviceID, QJsonDocument(obj).toJson());
    }
    else if (index == 2)
    {
        QJsonObject obj;

        obj.insert("cmd", "menu");
        obj.insert("tab", "3");

        client->publish(deviceID, QJsonDocument(obj).toJson());
    }
    else if (index == 3)
    {
        QJsonObject obj;

        obj.insert("cmd", "menu");
        obj.insert("tab", "4");

        client->publish(deviceID, QJsonDocument(obj).toJson());
    }
}

void SmartHome::on_alarmTimeEdit_editingFinished()
{
    int hour = ui->alarmTimeEdit->time().hour();
    int min = ui->alarmTimeEdit->time().minute();

    QJsonObject obj;

    obj.insert("cmd", "alarm");
    obj.insert("hour", hour);
    obj.insert("min", min);

    client->publish(deviceID, QJsonDocument(obj).toJson());
}

void SmartHome::on_commitButton_clicked()
{
    int hour = ui->noteTimeEdit->time().hour();
    int min = ui->noteTimeEdit->time().minute();

    int thing = 0;
    if (ui->oneRadioButton->isChecked())
    {
        thing = 1;
    }
    else if (ui->twoRadioButton->isChecked())
    {
        thing = 2;
    }
    else if (ui->threeRadioButton->isChecked())
    {
        thing = 3;
    }

    QJsonObject obj;

    obj.insert("cmd", "note");
    obj.insert("hour", hour);
    obj.insert("min", min);
    obj.insert("thing", thing);

    client->publish(deviceID, QJsonDocument(obj).toJson());
}
